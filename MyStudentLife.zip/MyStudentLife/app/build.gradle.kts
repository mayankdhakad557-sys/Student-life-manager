plugins { id("com.android.application") }
android {
    namespace = "com.mystudentlife.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mystudentlife.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
